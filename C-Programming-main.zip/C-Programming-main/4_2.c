#include <stdio.h>
int main() {
    int a[10], i;
    for(i = 0; i < 10; i++)
        scanf("%d", &a[i]);
    printf("%d %d %d", a[3], a[6], a[8]);
    return 0;
}
