#include<stdio.h>

int main(){
   
    float r,a;
    printf("enter radius");
    scanf("%f" , &r);

    a=(22/7)*r*r;
    printf("the area is %f " , a);
    return 0;
}