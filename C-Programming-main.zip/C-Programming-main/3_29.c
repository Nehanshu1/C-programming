#include <stdio.h>

int main() {
    int n, i, x = 0;
    printf("Enter a number: ");
    scanf("%d", &n);

    if (n <= 1)
        printf("Not a prime number");
    else {
        for (i = 2; i <= n / 2; i++) {
            if (n % i == 0) {
                x = 1;
                break;
            }
        }

        if (x == 0)
            printf("Prime number");
        else
            printf("Not a prime number");
    }

    return 0;
}
